import{a as e}from"./rolldown-runtime-Cyuzqnbw.js";import{V as t}from"./charts-C7Kdt1ey.js";import{a as n,i as r,n as i,r as a}from"./maps-BcjjFC06.js";import{d as o}from"./motion-CEh_iPn9.js";import{t as s}from"./leafletStyles-B9_xG-sh.js";var c=e(t(),1),l=o(),u=({bounds:e})=>{let t=n();return(0,c.useEffect)(()=>{t.fitBounds(e)},[e,t]),null},d=({data:e,metric:t,getColor:n,onStateClick:o,getValue:d,tooltipFormatter:f,selectedStateCode:p})=>{let[m,h]=(0,c.useState)(null);(0,c.useEffect)(()=>{s()},[]),(0,c.useEffect)(()=>{fetch(`/india-states.geojson`).then(e=>e.json()).then(e=>h(e)).catch(e=>console.error(`Error loading GeoJSON:`,e))},[]);let g=e=>e?e.toLowerCase().replace(/&/g,`and`).replace(/[^a-z]/g,``):``,_=(t,r)=>{let i=t.properties.STNAME||t.properties.stname||t.properties.NAME_1,a=e.find(e=>g(e.state_name)===g(i)),s=p&&a?.state_code===p,c=n(a?d(a):0);r.setStyle({fillColor:a?c:`rgba(42, 46, 53, 0.4)`,weight:s?2:1,opacity:1,color:s?`#3b82f6`:`rgba(255, 255, 255, 0.1)`,fillOpacity:s?1:.8}),r.on({mouseover:e=>{let t=e.target;s||(t.setStyle({weight:2,color:`#fff`,fillOpacity:.9}),t.bringToFront())},mouseout:e=>{let t=e.target;s||t.setStyle({weight:1,color:`rgba(255, 255, 255, 0.1)`,fillOpacity:.8})},click:()=>{a&&o&&o(a)}}),a&&r.bindTooltip(f(a),{sticky:!0,className:`leaflet-custom-tooltip`})};if(!m)return(0,l.jsx)(`div`,{className:`h-full w-full flex items-center justify-center text-white/20 uppercase tracking-uppercase font-black text-xs`,children:`Loading Cartography...`});let v=[[6.4626999,68.1097],[35.513327,97.395358]];return(0,l.jsxs)(`div`,{className:`h-full w-full relative rounded-3xl overflow-hidden border border-white/5 shadow-2xl`,children:[(0,l.jsxs)(a,{bounds:v,style:{height:`100%`,width:`100%`,background:`#020617`},zoomControl:!1,attributionControl:!1,scrollWheelZoom:!1,doubleClickZoom:!1,children:[(0,l.jsx)(i,{url:`https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png`}),(0,l.jsx)(u,{bounds:v}),(0,l.jsx)(r,{data:m,onEachFeature:_},t)]}),(0,l.jsx)(`style`,{dangerouslySetInnerHTML:{__html:`
                .leaflet-custom-tooltip {
                    background: rgba(2, 6, 23, 0.9) !important;
                    border: 1px solid rgba(255, 255, 255, 0.1) !important;
                    color: white !important;
                    border-radius: 12px !important;
                    padding: 8px 12px !important;
                    font-family: 'Inter', sans-serif !important;
                    font-size: 0.7rem !important;
                    font-weight: 700 !important;
                    backdrop-filter: blur(8px) !important;
                    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.5) !important;
                }
                .leaflet-container {
                    cursor: crosshair !important;
                }
            `}})]})};export{d as IndiaLeafletMap};